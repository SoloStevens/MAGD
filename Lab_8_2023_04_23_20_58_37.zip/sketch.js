var img1;
var img2;
var png;

function preload() {
  img1 = loadImage('assets/jpg.jpg');
  img2 = loadImage('assets/jpeg.jpeg');
  png = loadImage('assets/png.png');
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  image(img1, 25, 25, 50, 50);
  image(img2, 325, 25, 50, 50);
  image(png, 175, 25, 50, 50);
  textFont('Helvitica');
  textSize(30);
  fill('Red');
  stroke('Green');
  text('text', 175, 100);
  text('longText longText longText longText longText longText longText longText longText longText longText longText ', 175, 200, 100, 200)
}