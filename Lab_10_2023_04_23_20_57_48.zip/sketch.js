var vid;

function setup() {
  noCanvas();
  vid = createVideo(
    ['videos/Battery Vine AAA.mp4', 'videos/Battery Vine AAA.ovg', 'videos/Battery Vine AAA.webm'],
    vidLoad
  );
  vid.size(400, 400);
}

function draw(){
  background(220);
}

function vidLoad() {
  vid.loop();
  vid.volume(0.05);
}