var audio;
var soundLoop;
var sine = new p5.Oscillator('sine');
var res = 41;
var ampVis = 10;
var offset = 0;
var capture;

function preload() {
  soundFormats('mp3', 'ogg');
  audio = loadSound('assets/rickroll.mp3');
}

function setup() {
  createCanvas(400, 400);
  //audio.play();
  audio.playMode('restart');
  soundLoop = new p5.SoundLoop(audioLoop(), 212);
  soundLoop.start();
  sine.start();
  capture = createCapture(VIDEO);
  capture.hide();
}

function draw() {
  background(220);
  image(capture, 0, 0, width, width * capture.height / capture.width);
  filter(GRAY);
  waveform(offset);
  offset++;
  offset%=res*4;
  
}

function audioLoop(timeFromNow){
  audio.stop();
  audio.play();
}

function waveform(offset){
  for (var i = 0; i < res; i++){
    circle((400/res)*i, (Math.sin(i+offset)*ampVis)+height - (width * capture.height / capture.width) / 2, 10);
  }
}